<?php
require_once BASE_MD . '/BaseModels.php';

class SliderModel extends BaseModels
{
    protected $table_name = 'slider';
    protected $primary_key = 'id';
}