<?php
require_once BASE_MD . '/BaseModels.php';

class MenuModel extends BaseModels
{
    protected $table_name = 'menu';
    protected $primary_key = 'id';
}