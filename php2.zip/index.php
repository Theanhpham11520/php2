<?php
require_once './config.php';
require_once BASE_MAIN . '/Publics/helper.php';
require_once BASE_MAIN . '/Routers/main.php';