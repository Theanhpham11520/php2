<?php
session_start();
define('BASE_MAIN', __DIR__);
define('LIB_MAIN', '/Publics/main');
define('LIB', '/Publics');
define('LIB_ADMIN', '/Publics/admin');
define('LIB_USER', '/Publics/user');
define('ViewMain', BASE_MAIN . '/Resources/main/');
define('ViewAdmin', BASE_MAIN . '/Resources/admin/');
define('LAYOUT', BASE_MAIN . '/Resources/layout/');
define('BASE_Ctl', BASE_MAIN . '/Controllers');
define('BASE_MD', BASE_MAIN . '/Models');
define('STORAGE_DIR', '/storage');
define('DB_NAME', 'php2');
define('DB_USERNAME', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');

