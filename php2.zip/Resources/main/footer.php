<div class="footer-area">
    <div class="footer-copyright">
        <div class="container wide">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copyright-wrapper footer-copyright-wrapper--default-footer">
                        <div class="container">
                            <div class="row align-items-center no-gutters">
                                <div class="col-lg-2 col-md-2">
                                    <div class="footer-logo">
                                        <a href="/"><img src="<?php echo LIB_MAIN . '/img/logo.png' ?>" class="img-fluid" alt="" /></a>
                                    </div>
                                </div>

                                <div class="col-lg-7 col-md-5">
                                    <div class="copyright-text">Bản quyền &copy; 2021 <a href="#">PHP2</a>. Đã đăng ký Bản quyền.</div>
                                </div>
                                <div class="col-lg-3 col-md-5">
                                    <div class="copyright-social-wrapper">
                                        <ul class="copyright-social">
                                            <li>
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                            </li>
                                            <li>
                                                <a href="#"><i class="fa fa-twitter"></i></a>
                                            </li>
                                            <li>
                                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li>
                                                <a href="#"><i class="fa fa-youtube"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--====================  End of footer area  ====================-->
<?php require ViewMain . '/hfrepornsive.php' ?>


<!-- scroll to top  -->
<div id="scroll-top"><span>đầu trang!</span><i class="ion-chevron-right"></i><i class="ion-chevron-right"></i></div>
