<div class="footer">
    <div class="copyright">
        <p>Bản quyền &copy; 2021 <a href="#">PHP2</a>. Đã đăng ký Bản quyền.</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->